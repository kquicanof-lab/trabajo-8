"""Programa principal: menú de consola para los dos problemas DP."""
from src.escaleras import escaleras
from src.cambio_monedas import cambio_minimo


def ejecutar_escaleras():
    n = int(input("Número de escalones N: "))
    formas, dp = escaleras(n)
    print(f"Formas posibles: {formas}")
    print("Tabla DP:")
    print(dp)


def ejecutar_monedas():
    monedas = list(map(int, input("Monedas (separadas por espacio): ").split()))
    cantidad = int(input("Cantidad objetivo: "))
    minimo, dp, comb = cambio_minimo(monedas, cantidad)
    if minimo == -1:
        print("Cantidad mínima de monedas: imposible formar esa cantidad")
        print("Combinación: ninguna")
    else:
        print(f"Cantidad mínima de monedas: {minimo}")
        print("Combinación:", " + ".join(map(str, comb)) if comb else "(vacía)")
    print("Tabla DP:")
    print([("inf" if v == float("inf") else v) for v in dp])


def main():
    print("1) Escaleras\n2) Cambio mínimo de monedas")
    op = input("Opción: ").strip()
    try:
        if op == "1":
            ejecutar_escaleras()
        elif op == "2":
            ejecutar_monedas()
        else:
            print("Opción no válida.")
    except ValueError as e:
        print("Entrada inválida:", e)


if __name__ == "__main__":
    main()
