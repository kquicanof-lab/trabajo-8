"""Problema 1: Escaleras (Programación Dinámica)."""


def escaleras(n):
    """
    Cuenta las formas de llegar al escalón n avanzando 1 o 2 escalones.

    Estado:      dp[i] = formas de llegar exactamente al escalón i.
    Recurrencia: dp[i] = dp[i-1] + dp[i-2]
    Casos base:  dp[0] = 1, dp[1] = 1.

    Retorna: (formas, tabla_dp)
    """
    if n < 0:
        raise ValueError("N debe ser un entero no negativo.")

    dp = [0] * (n + 1)
    dp[0] = 1                   # caso base
    if n >= 1:
        dp[1] = 1               # caso base

    for i in range(2, n + 1):   # llenado de abajo hacia arriba
        dp[i] = dp[i - 1] + dp[i - 2]

    return dp[n], dp
