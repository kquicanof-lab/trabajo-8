"""Problema 2: Cambio mínimo de monedas (Programación Dinámica)."""

INF = float("inf")


def cambio_minimo(monedas, cantidad):
    """
    Calcula el mínimo de monedas para formar 'cantidad' exacta.

    Estado:      dp[x] = mínimo de monedas para formar x.
    Recurrencia: dp[x] = min(dp[x - c] + 1) para toda moneda c <= x.
    Casos base:  dp[0] = 0; el resto inicia en infinito.

    Retorna: (minimo, tabla_dp, combinacion); minimo = -1 si no hay solución.
    """
    if cantidad < 0:
        raise ValueError("La cantidad no puede ser negativa.")
    monedas = sorted(set(c for c in monedas if c > 0))

    dp = [INF] * (cantidad + 1)
    ultima = [0] * (cantidad + 1)   # última moneda usada, para reconstruir
    dp[0] = 0

    for x in range(1, cantidad + 1):
        for c in monedas:
            if c <= x and dp[x - c] + 1 < dp[x]:
                dp[x] = dp[x - c] + 1
                ultima[x] = c

    if dp[cantidad] == INF:
        return -1, dp, []

    combinacion, x = [], cantidad
    while x > 0:                    # reconstrucción de la combinación
        combinacion.append(ultima[x])
        x -= ultima[x]

    return dp[cantidad], dp, sorted(combinacion, reverse=True)
