# Programación Dinámica: Escaleras y Cambio mínimo de monedas

Proyecto en **Python 3** que resuelve dos problemas clásicos con Programación Dinámica.

## Estructura

```
.
├── main.py                 # menú de consola
├── src/
│   ├── escaleras.py        # Problema 1
│   └── cambio_monedas.py   # Problema 2
└── README.md
```

## Requisitos

- Python 3.8 o superior (no necesita librerías externas).

## Cómo ejecutar

```bash
git clone https://github.com/<tu-usuario>/<tu-repositorio>.git
cd <tu-repositorio>
python main.py
```

Elige `1` (Escaleras) o `2` (Cambio de monedas) e ingresa los datos.

### Ejemplo 1: Escaleras

```
Opción: 1
Número de escalones N: 5
Formas posibles: 8
Tabla DP:
[1, 1, 2, 3, 5, 8]
```

### Ejemplo 2: Cambio mínimo

```
Opción: 2
Monedas (separadas por espacio): 1 3 4
Cantidad objetivo: 6
Cantidad mínima de monedas: 2
Combinación: 3 + 3
Tabla DP:
[0, 1, 2, 1, 1, 2, 2]
```

## Resumen de los algoritmos

| Problema | Estado | Recurrencia | Casos base | Tiempo | Espacio |
|---|---|---|---|---|---|
| Escaleras | `dp[i]` = formas de llegar al escalón i | `dp[i] = dp[i-1] + dp[i-2]` | `dp[0]=1`, `dp[1]=1` | O(N) | O(N) |
| Monedas | `dp[x]` = mínimo de monedas para x | `dp[x] = min(dp[x-c] + 1)` | `dp[0]=0`, resto = ∞ | O(M·C) | O(M) |

M = cantidad objetivo, C = número de denominaciones.

## Autor

Tu nombre: curso / universidad.
